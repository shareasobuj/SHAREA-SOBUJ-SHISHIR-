const Contact = () => {
  return (
    <section className="p-8 bg-gray-100">
      <h2 className="text-3xl font-bold mb-4">Contact</h2>
      <p>Email: sobuj@example.com</p>
      <p>GitHub: <a className="text-blue-500 underline" href="https://github.com/shareasobuj">shareasobuj</a></p>
    </section>
  );
};

export default Contact;