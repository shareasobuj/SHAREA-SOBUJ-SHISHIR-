const Projects = () => {
  return (
    <section className="p-8">
      <h2 className="text-3xl font-bold mb-4">Projects</h2>
      <ul className="list-disc list-inside">
        <li><a className="text-blue-500 underline" href="https://github.com/shareasobuj/to-do-list">To-Do List App</a></li>
        <li><a className="text-blue-500 underline" href="https://github.com/shareasobuj/calculator">Calculator App</a></li>
        <li><a className="text-blue-500 underline" href="https://github.com/shareasobuj/portfolio">Responsive Portfolio Website</a></li>
      </ul>
    </section>
  );
};

export default Projects;