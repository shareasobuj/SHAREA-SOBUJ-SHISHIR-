const Skills = () => {
  return (
    <section className="p-8 bg-gray-100">
      <h2 className="text-3xl font-bold mb-4">Skills</h2>
      <ul className="list-disc list-inside">
        <li>HTML | CSS | JavaScript</li>
        <li>React.js (Learning)</li>
        <li>Git & GitHub</li>
      </ul>
    </section>
  );
};

export default Skills;