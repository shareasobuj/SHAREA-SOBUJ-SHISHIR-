const Footer = () => {
  return (
    <footer className="p-4 bg-indigo-900 text-white text-center">
      <p>&copy; 2025 SHAREA SOBUJ SHISHIR. All rights reserved.</p>
    </footer>
  );
};

export default Footer;