const Hero = () => {
  return (
    <section className="h-screen flex flex-col justify-center items-center bg-indigo-900 text-white text-center">
      <h1 className="text-5xl font-bold mb-4">Hi, I'm SHAREA SOBUJ SHISHIR</h1>
      <p className="text-xl">Junior Frontend Developer</p>
    </section>
  );
};

export default Hero;